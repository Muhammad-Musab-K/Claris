import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { ColorRing } from 'react-loader-spinner'
import { Button, CheckPicker, Stack } from 'rsuite';

import Navbar from '../components/Navbar'
import arrow from "../assests/back.png"
import { restaurentsData } from '../redux/RestaurantsSlice'
import Bookings from './Bookings'

function Restraurents() {
    const dispatch = useDispatch()
    const { id } = useParams()
    const navigate = useNavigate()
    const [ids, setIds] = useState([])
    const [restro, setRestro] = useState([])

    const handleBack = () => {
        navigate(-1)
    }

    let city;
    if (id == 1) city = "Milano"
    else if (id == 3) city = "Bali"
    else if (id == 2) city = "Dubai"
    const token = useSelector(state => state?.loginUser?.token)

    useEffect(() => {
        if (token) dispatch(restaurentsData({ id, token }))
    }, [id])

    const handleValueChnage = (value) => setRestro(value)
    const handleIdChange = () => setIds(restro)

    const data = useSelector(state => state?.restaurant?.restaurents)
    console.log(data)

    // if (!data) {
    //     return (
    //         <div className="flex justify-center items-center h-screen">
    //             <ColorRing
    //                 visible={true}
    //                 height="80"
    //                 width="80"
    //                 ariaLabel="color-ring-loading"
    //                 wrapperStyle={{}}
    //                 wrapperClass="color-ring-wrapper"
    //                 colors={['#e15b64', '#f47e60', '#f8b26a', '#abbd81', '#849b87']}
    //             />
    //         </div>
    //     );
    // }
    const restrau = data?.map((item => ({ label: item.Name, value: item.id })))

    return (
        <div className='w-full mb-4'>
            <Navbar />
            <div className='m-6'>
                <img
                    onClick={handleBack}
                    className='w-6 h-6 absolute'
                    src={arrow} alt="" />
                <h1 className=' font-semibold text-4xl text-center'>{city}</h1>
            </div>

            <div className='mt-4 flex flex-col flex-wrap justify-center items-center md:flex-row gap-2 w-11/12 max-w-5xl m-auto'>
                <Stack spacing={10} direction="row" alignItems="flex-start">
                    <CheckPicker
                        style={{ boxShadow: 'none' }}
                        value={restro}
                        data={restrau}
                        className='w-[250px] md:w-[500px]'
                        onChange={handleValueChnage}
                        onClean={() => setIds([])} />
                    <Button
                        onClick={handleIdChange}
                        className="bg-[#FF004F] text-white shadow-none border-none">
                        Apply
                    </Button>
                </Stack>
            </div>
            <Bookings ids={ids} restraurantId={id} />
        </div>
    )
}

export default Restraurents
