import React, { useEffect } from 'react'
import TikTok from "../assests/tiktok.png"
import Insta from "../assests/insta.png"
import { Link } from 'react-router-dom'
import Span from "./Span"

function Cards({ ...item }) {

    const bookingCompleted = () => {
        if (item?.BookingDay) {
            const bookingDate = new Date(item.BookingDay).getTime();
            return bookingDate > Date.now()
        }
        return false
    }
    const bookingStatus = () => {
        if (item.canceled) return <Span bg_color="bg-red-500" text="Canceled" />
        if (item.Rejectedstatus) return <Span bg_color="bg-red-500" text="Denied" />
        if (!item?.Approved && !item?.canceled && !item.Rejectedstatus) return <Span bg_color="bg-yellow-500" text="Pending" />
        if (item?.Approved && bookingCompleted()) return <Span bg_color="bg-green-700" text="Incoming" />
        if (item?.Approved && !bookingCompleted()) return <Span bg_color="bg-green-400" text="Completed" />
    }

    return (
        <div className='border-2  mb-3 w-full md:m-2 md:w-[250px] flex flex-col gap-5 bg-slate-50 rounded-lg p-4'>
            <div
                style={{
                    backgroundImage: `url(${item?.restaurant_turbo?.Cover?.url})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                }}
                className='h-32 md:h-24 rounded-lg  px-1 flex justify-between pt-1 ' >
                <span className='h-6 text-xs text-white bg-[#FF004F] rounded-md px-1 pt-1'>{item?.restaurant_turbo.Name}</span>
                {bookingStatus()}

            </div>
            <div className='flex gap-4 relative'>
                <img className='h-16 w-16 rounded-lg' src={item?.user_turbo?.Profile_pic?.url || "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVrLgzSMdH62yI75gb9jx3MTTR0o0VLDntTteWqR6rPQ&s"} alt="" />

                <div className='flex flex-col gap-2 '>
                    <h1 className='font-semibold text-lg md:text-xl text-black'>{item?.user_turbo?.name || "unknown"}</h1>
                    <div className='flex gap-6 items-center '>
                        {item.actions_turbo?.Action_icon && <img className='h-6 w-6 ' src={item.actions_turbo?.Action_icon.url} alt="" />}
                        {item?.user_turbo?.Tiktok_account && (<Link to={`https://tiktok/en/${item?.user_turbo?.Tiktok_account}`}><img className='h-6 w-6' src={TikTok} alt="" /></Link>)}
                        {item?.user_turbo?.IG_account && (<Link to={`https://instagram.com/${item?.user_turbo?.IG_account}`}><img className='h-8 w-8' src={Insta} alt="" /></Link>)}

                    </div>



                </div>

            </div>
            <div className='flex flex-col'>
                <p className=' text-sm text-slate-500 md:font-semibold'>Booking Day <span className='ml-6  text-sm text-black'>{item?.BookingDay}</span></p>
                <p className=' text-sm text-slate-500 md:font-semibold'>Booking Time <span className='ml-5  text-sm text-black'>{item?.timeframes_turbo?.Start}:{item?.timeframes_turbo?.Minute_Start} - {item?.timeframes_turbo?.End}:{item?.timeframes_turbo?.Minute_End}</span></p>
            </div>
        </div>
    )
}

export default Cards
