import React from 'react'

function Span({ bg_color, text }) {
    return (
        <span className={`h-6 text-xs text-white  ${bg_color}  rounded-md px-1 pt-1`}>
            {text}
        </span>
    )
}

export default Span
